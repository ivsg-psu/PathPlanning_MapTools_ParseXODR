# struct2xml FEX 59411
MATLAB function that converts a structure into xml format ( or file ). 
