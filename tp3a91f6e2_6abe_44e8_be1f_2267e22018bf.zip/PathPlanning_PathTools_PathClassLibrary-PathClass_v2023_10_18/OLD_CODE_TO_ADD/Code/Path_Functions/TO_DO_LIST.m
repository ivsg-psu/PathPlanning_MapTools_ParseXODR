TO_DO List

FINISH input argument checking functions
script_main_laneChange.m - clean this up
create function from switch-back subfunction within path averaging

LATER:
Weighted averaging of paths (so we can add paths collected later)
a function that finds where intersections and lange changes occur within many paths by looking at change in yaw relative to mean?
a function to find where paths cross
a function to find where paths diverage?

